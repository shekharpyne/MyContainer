package com.ibm.travelplanner.domain;

import java.util.Date;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;


@Document(collection = "Package")

public class TourPackage {
	
	@Id
	 private Long id;
	 
	 private String sourcePlace;
	 
	 private String destinationPlace;
	 
	 private Date date;
	 
	 private List<PackageType> packageType;
	 
	 public TourPackage(){
		 
	 }

	public TourPackage(Long id, String sourcePlace, String destinationPlace, int duration, Date date,
			List<PackageType> packageType) {
		this.id = id;
		this.sourcePlace = sourcePlace;
		this.destinationPlace = destinationPlace;
		this.date = date;
		this.packageType = packageType;
	}

	public long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getSourcePlace() {
		return sourcePlace;
	}

	public void setSourcePlace(String sourcePlace) {
		this.sourcePlace = sourcePlace;
	}

	public String getDestinationPlace() {
		return destinationPlace;
	}

	public void setDestinationPlace(String destinationPlace) {
		this.destinationPlace = destinationPlace;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public List<PackageType> getPackageType() {
		return packageType;
	}

	public void setPackageType(List<PackageType> packageType) {
		this.packageType = packageType;
	}

	 
}
