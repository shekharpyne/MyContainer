package com.ibm.travelplanner.domain;

public class PackageType {

	private String packageName;
	private Long packageCost;
	private String tourDetails;
	 private int duration;
	
	
	public PackageType(String packageName, Long packageCost, String tourDetails, int duration) {
		this.packageName = packageName;
		this.packageCost = packageCost;
		this.tourDetails = tourDetails;
		this.duration = duration;
	}
	
	public String getPackageName() {
		return packageName;
	}
	public void setPackageName(String packageName) {
		this.packageName = packageName;
	}
	public Long getPackageCost() {
		return packageCost;
	}
	public void setPackageCost(Long packageCost) {
		this.packageCost = packageCost;
	}
	public String getTourDetails() {
		return tourDetails;
	}
	public void setTourDetails(String tourDetails) {
		this.tourDetails = tourDetails;
	}

	@Override
	public String toString() {
		return "PackageType [packageName=" + packageName + ", packageCost=" + packageCost + ", tourDetails="
				+ tourDetails + "]";
	}

	public int getDuration() {
		return duration;
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}
	
}
