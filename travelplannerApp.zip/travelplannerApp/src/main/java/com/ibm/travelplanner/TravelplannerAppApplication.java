package com.ibm.travelplanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TravelplannerAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(TravelplannerAppApplication.class, args);
	}

}
