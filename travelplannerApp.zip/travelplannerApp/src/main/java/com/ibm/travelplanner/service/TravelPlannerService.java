package com.ibm.travelplanner.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ibm.travelplanner.domain.PackageType;
import com.ibm.travelplanner.domain.TourPackage;
import com.ibm.travelplanner.repository.PackageRepositiory;

@Service
public class TravelPlannerService {

	@Autowired
	private PackageRepositiory repositiory;
	
	List<TourPackage> packages= new ArrayList<TourPackage>(Arrays.asList(
			new TourPackage(10000004l, "Kolkata", "UAE", 6, new Date(), new ArrayList<>(Arrays.asList(new PackageType("Value Plus1", 100000l, "AAA-->BB-->CC",5),
					new PackageType("Value Plus2", 200000l, "AAA-->BB-->CC",6), new PackageType("Value Plus3", 300000l, "AAA-->BB-->CC",7)))),
			new TourPackage(10000005l, "Kolkata", "NJP", 7, new Date(),  new ArrayList<>(Arrays.asList(new PackageType("Value Plus1", 100000l, "AAA-->BB-->CC",5),
					new PackageType("Value Plus2", 200000l, "AAA-->BB-->CC",6), new PackageType("Value Plus3", 300000l, "AAA-->BB-->CC",7)))),
			new TourPackage(10000006l, "Kolkata", "URI", 4, new Date(),  new ArrayList<>(Arrays.asList(new PackageType("Value Plus1", 100000l, "AAA-->BB-->CC",5),
					new PackageType("Value Plus2", 200000l, "AAA-->BB-->CC",6), new PackageType("Value Plus3", 300000l, "AAA-->BB-->CC",7))))));

	
	public List<TourPackage> getAllPackage(){
		List<TourPackage> packageList= new ArrayList<TourPackage>();
		repositiory.findAll()
		.forEach(packageList::add);
		return packageList;
	}
	
	public List<TourPackage> savePackage(){
		packages.forEach(i->repositiory.save(i));
		return packages;
	}
	
	public List<TourPackage> findByTourPackageDestinationPlace(String destinationPlace){
		return repositiory.findByDestinationPlace(destinationPlace);
	}
	
	public TourPackage findByTourPackageDestinationPlaceAndSource(String destinationPlace, String sourcePlace){
		return repositiory.findByDestinationPlaceAndSourcePlace(destinationPlace, sourcePlace);
	}
	
	public void deleteAllPackages(){
		 repositiory.deleteAll();
	}
	
	public void deletePackage(String id){
		 repositiory.deleteById(id);
	}
	
}
