package com.ibm.travelplanner.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ibm.travelplanner.domain.TourPackage;
import com.ibm.travelplanner.service.TravelPlannerService;


@RestController
@CrossOrigin(origins="*")
@RequestMapping("/api")
public class TravelPlannerController {
	
	@Autowired
	private TravelPlannerService plannerService;
	
	@GetMapping(value="/packages")
	public List<TourPackage> getPackages(){
		return plannerService.getAllPackage();
	}
	
	@GetMapping(value="/save-packages")
//	public void addTopic(@RequestBody Topic topic){
	public List<TourPackage> addTopic(){
		return plannerService.savePackage();
	}
	
	@GetMapping(value="/packages/{dst}")
//	public void addTopic(@RequestBody Topic topic){
	public List<TourPackage> getPackage(@PathVariable(value = "dst") String dst){
		return plannerService.findByTourPackageDestinationPlace(dst);
	}
	
	@GetMapping(value="/deleteall")
	public void deleteAll(){
		 plannerService.deleteAllPackages();
	}
	
	@GetMapping(value="/delete/{packId}")
	public void getTopic(@PathVariable(value = "packId") String packId){
		 plannerService.deletePackage(packId);
	}
	
	@GetMapping(value="/packages/{source}/to/{dst}")
	public TourPackage findPackage(@PathVariable(value = "dst") String destinationPlace,@PathVariable(value = "source") String sourcePlace){
		return plannerService.findByTourPackageDestinationPlaceAndSource(destinationPlace, sourcePlace);
	}
}
