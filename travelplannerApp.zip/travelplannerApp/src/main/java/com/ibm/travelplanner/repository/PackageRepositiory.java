package com.ibm.travelplanner.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.ibm.travelplanner.domain.TourPackage;

public interface PackageRepositiory extends MongoRepository<TourPackage, String>{
	
	public List<TourPackage> findByDestinationPlace(String destinationPlace);
	public TourPackage findByDestinationPlaceAndSourcePlace(String Source, String destination);

//    //Supports native JSON query string
//    @Query("{domain:'?0'}")
//    TourPackage findCustomByDomain(String domain);
//
//    @Query("{domain: { $regex: ?0 } })")
//    List<TourPackage> findCustomByRegExDomain(String domain);
}
