package com.ibm.travelplanner;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TravelplannerAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
